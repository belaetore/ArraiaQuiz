
import React from 'react';
import { Play, Trophy, Target } from 'lucide-react';

interface StartScreenProps {
  onStartGame: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({ onStartGame }) => {
  return (
    <div className="max-w-2xl mx-auto text-center animate-slide-up">
      <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-8 border-2 border-gray-400 shadow-2xl">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-800 mb-6 uppercase">
            BEM-VINDO AO QUIZ!
          </h2>
          
          <p className="text-lg text-gray-700 mb-6 leading-relaxed uppercase">
            TESTE SEUS CONHECIMENTOS SOBRE AS TRADIÇÕES JUNINAS BRASILEIRAS! 
            SÃO 10 PERGUNTAS DESAFIADORAS SOBRE SANTOS JUNINOS, TRADIÇÕES, 
            SIMPATIAS E MUITO MAIS.
          </p>

          <div className="grid md:grid-cols-3 gap-4 mb-8">
            <div className="bg-blue-100 rounded-lg p-4 border border-blue-400">
              <Trophy className="text-blue-600 mx-auto mb-2" size={32} />
              <h3 className="font-bold text-blue-800 mb-1 uppercase">SISTEMA DE PONTOS</h3>
              <p className="text-sm text-blue-700 uppercase">
                FÁCIL: 5PTS | MÉDIO: 10PTS | DIFÍCIL: 15PTS
              </p>
            </div>
            
            <div className="bg-green-100 rounded-lg p-4 border border-green-400">
              <Target className="text-green-600 mx-auto mb-2" size={32} />
              <h3 className="font-bold text-green-800 mb-1 uppercase">NÍVEL DESAFIADOR</h3>
              <p className="text-sm text-green-700 uppercase">
                PERGUNTAS QUE VÃO TESTAR SEU CONHECIMENTO JUNINO!
              </p>
            </div>
            
            <div className="bg-purple-100 rounded-lg p-4 border border-purple-400">
              <Play className="text-purple-600 mx-auto mb-2" size={32} />
              <h3 className="font-bold text-purple-800 mb-1 uppercase">TRADIÇÕES BRASILEIRAS</h3>
              <p className="text-sm text-purple-700 uppercase">
                SANTOS, SIMPATIAS, DANÇAS E MUITO MAIS!
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={onStartGame}
          className="group bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600 text-white font-bold py-4 px-8 rounded-full text-xl transition-all duration-300 transform hover:scale-110 shadow-lg hover:shadow-xl flex items-center gap-3 mx-auto uppercase"
        >
          <Play className="group-hover:animate-pulse" size={24} />
          COMEÇAR O QUIZ!
        </button>

        <div className="mt-6 text-sm text-gray-600 uppercase">
          <p>🎯 DESAFIE-SE COM PERGUNTAS SOBRE NOSSA RICA CULTURA JUNINA!</p>
        </div>
      </div>
    </div>
  );
};
