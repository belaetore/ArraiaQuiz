
import React, { useState } from 'react';
import { Question } from '../data/questions';
import { CheckCircle, XCircle, Lightbulb } from 'lucide-react';

interface QuestionCardProps {
  question: Question;
  onAnswer: (selectedAnswer: number, isCorrect: boolean) => void;
  questionNumber: number;
  isAnswering: boolean;
}

export const QuestionCard: React.FC<QuestionCardProps> = ({
  question,
  onAnswer,
  questionNumber,
  isAnswering
}) => {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const handleAnswer = (answerIndex: number) => {
    if (showFeedback || isAnswering) return;
    
    setSelectedAnswer(answerIndex);
    setShowFeedback(true);
    
    const isCorrect = answerIndex === question.correctAnswer;
    onAnswer(answerIndex, isCorrect);
  };

  // Reset state when question changes
  React.useEffect(() => {
    setSelectedAnswer(null);
    setShowFeedback(false);
  }, [question]);

  const getDifficultyColor = () => {
    switch (question.difficulty) {
      case 'fácil': return 'text-green-700';
      case 'médio': return 'text-orange-700';
      case 'difícil': return 'text-red-700';
      default: return 'text-gray-700';
    }
  };

  const getDifficultyPoints = () => {
    switch (question.difficulty) {
      case 'fácil': return 5;
      case 'médio': return 10;
      case 'difícil': return 15;
      default: return 0;
    }
  };

  return (
    <div className="max-w-3xl mx-auto animate-slide-up">
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 border-2 border-red-400 shadow-xl">
        {/* Header da pergunta */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <span className="bg-red-500 text-white font-bold px-3 py-1 rounded-full uppercase">
              {questionNumber}/10
            </span>
            <span className={`font-semibold uppercase ${getDifficultyColor()}`}>
              {question.difficulty.toUpperCase()} - {getDifficultyPoints()}PTS
            </span>
          </div>
        </div>

        {/* Pergunta */}
        <div className="mb-8">
          <h3 className="text-xl font-bold text-red-800 leading-relaxed uppercase">
            {question.question.toUpperCase()}
          </h3>
        </div>

        {/* Opções de resposta */}
        <div className="space-y-4 mb-6">
          {question.options.map((option, index) => {
            let buttonClass = "w-full p-4 text-left rounded-lg border-2 transition-all duration-300 font-medium uppercase ";
            
            if (!showFeedback) {
              buttonClass += "bg-yellow-100 border-yellow-400 hover:bg-yellow-200 hover:border-yellow-500 text-yellow-800 hover:scale-[1.02]";
            } else {
              if (index === question.correctAnswer) {
                buttonClass += "bg-green-200 border-green-500 text-green-800";
              } else if (index === selectedAnswer && index !== question.correctAnswer) {
                buttonClass += "bg-red-200 border-red-500 text-red-800";
              } else {
                buttonClass += "bg-gray-200 border-gray-400 text-gray-600";
              }
            }

            return (
              <button
                key={index}
                onClick={() => handleAnswer(index)}
                disabled={showFeedback || isAnswering}
                className={buttonClass}
              >
                <div className="flex items-center justify-between">
                  <span>{String.fromCharCode(65 + index)}) {option.toUpperCase()}</span>
                  {showFeedback && index === question.correctAnswer && (
                    <CheckCircle className="text-green-600" size={24} />
                  )}
                  {showFeedback && index === selectedAnswer && index !== question.correctAnswer && (
                    <XCircle className="text-red-600" size={24} />
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Feedback e explicação */}
        {showFeedback && (
          <div className="animate-bounce-in bg-orange-100 border border-orange-400 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Lightbulb className="text-orange-600 flex-shrink-0 mt-1" size={20} />
              <div>
                <h4 className="font-bold text-orange-800 mb-2 uppercase">
                  {selectedAnswer === question.correctAnswer ? '🎉 CORRETO!' : '❌ INCORRETO!'}
                </h4>
                <p className="text-orange-800 text-sm leading-relaxed uppercase">
                  {question.explanation.toUpperCase()}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
