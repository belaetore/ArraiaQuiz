
import React from 'react';
import { GameStats } from './QuizGame';
import { Trophy, Clock, Target, RotateCcw, Award } from 'lucide-react';

interface ResultScreenProps {
  stats: GameStats;
  onPlayAgain: () => void;
}

export const ResultScreen: React.FC<ResultScreenProps> = ({ stats, onPlayAgain }) => {
  const percentage = Math.round((stats.correctAnswers / stats.totalQuestions) * 100);
  
  const getPerformanceMessage = () => {
    if (percentage >= 90) return { message: "🎉 EXCELENTE! 🎉", color: "text-green-700", bg: "from-green-100 to-blue-100" };
    if (percentage >= 70) return { message: "👏 MUITO BOM! 👏", color: "text-blue-700", bg: "from-blue-100 to-purple-100" };
    if (percentage >= 50) return { message: "👍 BOM TRABALHO! 👍", color: "text-purple-700", bg: "from-purple-100 to-pink-100" };
    return { message: "📚 CONTINUE ESTUDANDO! 📚", color: "text-gray-700", bg: "from-gray-100 to-blue-100" };
  };

  const performance = getPerformanceMessage();

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-2xl mx-auto animate-bounce-in">
      <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-8 border-2 border-gray-400 shadow-2xl text-center">
        
        {/* Header com resultado */}
        <div className="mb-8">
          <h2 className="text-4xl font-bold text-gray-800 mb-4 uppercase">
            QUIZ FINALIZADO!
          </h2>
          
          <div className={`bg-gradient-to-r ${performance.bg} rounded-2xl p-6 border border-gray-400 mb-6`}>
            <h3 className={`text-3xl font-bold ${performance.color} mb-2 uppercase`}>
              {performance.message}
            </h3>
            <p className="text-xl text-gray-800 uppercase">
              VOCÊ ACERTOU {stats.correctAnswers} DE {stats.totalQuestions} PERGUNTAS!
            </p>
          </div>
        </div>

        {/* Estatísticas */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-yellow-100 rounded-lg p-6 border border-yellow-400">
            <Trophy className="text-yellow-600 mx-auto mb-3" size={40} />
            <h4 className="text-2xl font-bold text-yellow-800 mb-2 uppercase">PONTUAÇÃO FINAL</h4>
            <p className="text-3xl font-bold text-yellow-700">{stats.score} PONTOS</p>
            <p className="text-sm text-yellow-700 mt-2 uppercase">
              APROVEITAMENTO: {percentage}%
            </p>
          </div>

          <div className="bg-blue-100 rounded-lg p-6 border border-blue-400">
            <Clock className="text-blue-600 mx-auto mb-3" size={40} />
            <h4 className="text-2xl font-bold text-blue-800 mb-2 uppercase">TEMPO TOTAL</h4>
            <p className="text-3xl font-bold text-blue-700">{formatTime(stats.timeElapsed)}</p>
            <p className="text-sm text-blue-700 mt-2 uppercase">
              MÉDIA: {Math.round(stats.timeElapsed / stats.totalQuestions)}S POR PERGUNTA
            </p>
          </div>
        </div>

        {/* Detalhamento */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="bg-green-100 rounded-lg p-4 border border-green-400">
            <Target className="text-green-600 mx-auto mb-2" size={24} />
            <p className="text-lg font-bold text-green-800">{stats.correctAnswers}</p>
            <p className="text-sm text-green-700 uppercase">ACERTOS</p>
          </div>
          
          <div className="bg-red-100 rounded-lg p-4 border border-red-400">
            <Award className="text-red-600 mx-auto mb-2" size={24} />
            <p className="text-lg font-bold text-red-800">{stats.wrongAnswers}</p>
            <p className="text-sm text-red-700 uppercase">ERROS</p>
          </div>
          
          <div className="bg-purple-100 rounded-lg p-4 border border-purple-400">
            <Trophy className="text-purple-600 mx-auto mb-2" size={24} />
            <p className="text-lg font-bold text-purple-800">{percentage}%</p>
            <p className="text-sm text-purple-700 uppercase">PRECISÃO</p>
          </div>
        </div>

        {/* Mensagem de encorajamento */}
        <div className="bg-gray-100 rounded-lg p-4 border border-gray-400 mb-8">
          <p className="text-gray-800 leading-relaxed uppercase">
            {percentage >= 70 
              ? "PARABÉNS! VOCÊ REALMENTE CONHECE AS TRADIÇÕES JUNINAS BRASILEIRAS! 🎊"
              : "CONTINUE ESTUDANDO SOBRE NOSSAS TRADIÇÕES JUNINAS. CADA FESTA É UMA OPORTUNIDADE DE APRENDER MAIS! 📚"
            }
          </p>
        </div>

        {/* Botão para jogar novamente */}
        <button
          onClick={onPlayAgain}
          className="group bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600 text-white font-bold py-4 px-8 rounded-full text-xl transition-all duration-300 transform hover:scale-110 shadow-lg hover:shadow-xl flex items-center gap-3 mx-auto uppercase"
        >
          <RotateCcw className="group-hover:animate-spin" size={24} />
          JOGAR NOVAMENTE
        </button>

        <div className="mt-6 text-sm text-gray-600 uppercase">
          <p>🎯 OBRIGADO POR CELEBRAR NOSSA CULTURA JUNINA CONOSCO!</p>
        </div>
      </div>
    </div>
  );
};
