
import React, { useState } from 'react';
import { Question, quizQuestions } from '../data/questions';
import { QuestionCard } from './QuestionCard';
import { ScoreBoard } from './ScoreBoard';
import { ResultScreen } from './ResultScreen';
import { StartScreen } from './StartScreen';

export type GameState = 'start' | 'playing' | 'finished';

export interface GameStats {
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  wrongAnswers: number;
  timeElapsed: number;
}

export const QuizGame: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>('start');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [wrongAnswers, setWrongAnswers] = useState(0);
  const [startTime, setStartTime] = useState<number>(0);
  const [shuffledQuestions, setShuffledQuestions] = useState<Question[]>([]);
  const [isAnswering, setIsAnswering] = useState(false);

  const shuffleArray = (array: Question[]) => {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  const startGame = () => {
    setShuffledQuestions(shuffleArray(quizQuestions));
    setGameState('playing');
    setCurrentQuestionIndex(0);
    setScore(0);
    setCorrectAnswers(0);
    setWrongAnswers(0);
    setStartTime(Date.now());
    setIsAnswering(false);
  };

  const handleAnswer = (selectedAnswer: number, isCorrect: boolean) => {
    if (isAnswering) return;
    
    setIsAnswering(true);
    
    if (isCorrect) {
      const points = getCurrentQuestion()?.difficulty === 'difícil' ? 15 : 
                     getCurrentQuestion()?.difficulty === 'médio' ? 10 : 5;
      setScore(score + points);
      setCorrectAnswers(correctAnswers + 1);
    } else {
      setWrongAnswers(wrongAnswers + 1);
    }

    setTimeout(() => {
      if (currentQuestionIndex < shuffledQuestions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setIsAnswering(false);
      } else {
        setGameState('finished');
      }
    }, 2000);
  };

  const getCurrentQuestion = () => shuffledQuestions[currentQuestionIndex];

  const getGameStats = (): GameStats => ({
    score,
    totalQuestions: shuffledQuestions.length,
    correctAnswers,
    wrongAnswers,
    timeElapsed: Math.floor((Date.now() - startTime) / 1000)
  });

  const resetGame = () => {
    setGameState('start');
    setIsAnswering(false);
  };

  return (
    <div className="min-h-screen bg-amber-100 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-6">
          <h1 className="text-6xl font-nunito font-black text-gray-800 drop-shadow-lg uppercase mb-4">
            QUIZ JUNINO
          </h1>
        </div>

        {gameState === 'start' && (
          <StartScreen onStartGame={startGame} />
        )}

        {gameState === 'playing' && getCurrentQuestion() && (
          <div className="space-y-4">
            <ScoreBoard 
              score={score}
              currentQuestion={currentQuestionIndex + 1}
              totalQuestions={shuffledQuestions.length}
            />
            <QuestionCard
              question={getCurrentQuestion()}
              onAnswer={handleAnswer}
              questionNumber={currentQuestionIndex + 1}
              isAnswering={isAnswering}
            />
          </div>
        )}

        {gameState === 'finished' && (
          <ResultScreen
            stats={getGameStats()}
            onPlayAgain={resetGame}
          />
        )}
      </div>
    </div>
  );
};
