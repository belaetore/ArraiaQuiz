
import React from 'react';
import { Trophy, Target } from 'lucide-react';

interface ScoreBoardProps {
  score: number;
  currentQuestion: number;
  totalQuestions: number;
}

export const ScoreBoard: React.FC<ScoreBoardProps> = ({
  score,
  currentQuestion,
  totalQuestions
}) => {
  const progress = (currentQuestion / totalQuestions) * 100;

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-xl p-4 border-2 border-gray-400 shadow-lg">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Trophy className="text-yellow-600" size={24} />
            <span className="text-gray-800 font-medium uppercase">PONTOS:</span>
            <span className="text-2xl font-bold text-blue-600">{score}</span>
          </div>
          
          <div className="hidden sm:flex items-center gap-2">
            <Target className="text-green-600" size={20} />
            <span className="text-gray-800 uppercase">
              PERGUNTA {currentQuestion} DE {totalQuestions}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-gray-800 font-medium uppercase">QUIZ JUNINO</span>
        </div>
      </div>

      {/* Barra de progresso */}
      <div className="mt-3">
        <div className="flex justify-between text-xs text-gray-800 mb-1 uppercase">
          <span>PROGRESSO</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
};
