
export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: 'fácil' | 'médio' | 'difícil';
  explanation: string;
}

export const quizQuestions: Question[] = [
  {
    id: 1,
    question: "Qual santo é tradicionalmente homenageado no dia 13 de junho, considerado um dos maiores protetores dos casamentos?",
    options: [
      "Santo Antônio",
      "São João",
      "São Pedro", 
      "São José"
    ],
    correctAnswer: 0,
    difficulty: "fácil",
    explanation: "Santo Antônio é conhecido como o santo casamenteiro e é celebrado no dia 13 de junho."
  },
  {
    id: 2,
    question: "Na tradição das simpatias juninas, o que se deve fazer na fogueira de São João para encontrar o amor verdadeiro?",
    options: [
      "Pular a fogueira 7 vezes",
      "Escrever o nome da pessoa amada e queimar",
      "Jogar pétalas de rosa no fogo",
      "Todas as alternativas estão corretas"
    ],
    correctAnswer: 3,
    difficulty: "médio",
    explanation: "Várias tradições envolvem a fogueira de São João para questões amorosas, incluindo todas essas práticas."
  },
  {
    id: 3,
    question: "Qual é a origem histórica da quadrilha junina no Brasil?",
    options: [
      "Dança africana trazida pelos escravos",
      "Dança indígena adaptada pelos jesuítas",
      "Dança francesa 'quadrille' adaptada no século XIX",
      "Criação original dos imigrantes alemães"
    ],
    correctAnswer: 2,
    difficulty: "difícil",
    explanation: "A quadrilha brasileira tem origem na dança francesa 'quadrille', que foi adaptada e abrasileirada no século XIX."
  },
  {
    id: 4,
    question: "Por que se acendem fogueiras na festa de São João?",
    options: [
      "Para assustar os maus espíritos",
      "Para comunicar o nascimento de João Batista a Maria",
      "Para aquecer nas noites frias de junho",
      "Para cozinhar o milho e a batata doce"
    ],
    correctAnswer: 1,
    difficulty: "médio",
    explanation: "Segundo a tradição cristã, Santa Isabel acendeu uma fogueira para avisar Maria sobre o nascimento de João Batista."
  },
  {
    id: 5,
    question: "Qual estado brasileiro é considerado o berço da maior festa junina do país?",
    options: [
      "Bahia",
      "Pernambuco", 
      "Ceará",
      "Paraíba"
    ],
    correctAnswer: 1,
    difficulty: "médio",
    explanation: "Pernambuco, especialmente Caruaru, é famoso por ter uma das maiores e mais tradicionais festas juninas do Brasil."
  },
  {
    id: 6,
    question: "Na tradição junina, qual é o significado da simpatia de colocar uma agulha em um copo d'água na noite de São João?",
    options: [
      "Descobrir se vai casar no próximo ano",
      "Prever o tempo do dia seguinte",
      "Saber quantos filhos terá",
      "Descobrir a profissão do futuro cônjuge"
    ],
    correctAnswer: 0,
    difficulty: "difícil",
    explanation: "Se a agulha formar uma cruz ou estrela na água pela manhã, significa que a pessoa se casará em breve."
  },
  {
    id: 7,
    question: "Qual é a diferença tradicional entre 'forró' e 'xote'?",
    options: [
      "Forró é mais rápido, xote é mais lento",
      "Forró é dançado em dupla, xote em grupo",
      "Não há diferença, são sinônimos",
      "Forró é do Nordeste, xote do Sudeste"
    ],
    correctAnswer: 0,
    difficulty: "difícil",
    explanation: "O xote é um subgênero do forró, tradicionalmente mais lento e romântico que outros ritmos do forró."
  },
  {
    id: 8,
    question: "Qual santo é invocado pelos pescadores e é celebrado no dia 29 de junho?",
    options: [
      "São João",
      "Santo Antônio",
      "São Pedro",
      "São Paulo"
    ],
    correctAnswer: 2,
    difficulty: "fácil",
    explanation: "São Pedro, que foi pescador, é o padroeiro dos pescadores e é celebrado no dia 29 de junho."
  },
  {
    id: 9,
    question: "Na tradição junina nordestina, o que é o 'casamento na roça'?",
    options: [
      "Cerimônia real realizada no campo",
      "Encenação teatral cômica durante as festas",
      "Ritual religioso de benção das plantações",
      "Dança tradicional apenas para casados"
    ],
    correctAnswer: 1,
    difficulty: "médio",
    explanation: "O casamento na roça é uma encenação cômica tradicional das festas juninas, com personagens estereotipados."
  },
  {
    id: 10,
    question: "Segundo a tradição popular, qual é a origem do nome 'arraial' para as festas juninas?",
    options: [
      "Palavra árabe que significa 'celebração'",
      "Palavra indígena para 'fogueira grande'",
      "Termo português para 'acampamento militar'",
      "Corruptela de 'real', referente às festas da realeza"
    ],
    correctAnswer: 2,
    difficulty: "difícil",
    explanation: "Arraial vem do termo militar português que designava um acampamento, depois passou a designar festivais populares."
  }
];
