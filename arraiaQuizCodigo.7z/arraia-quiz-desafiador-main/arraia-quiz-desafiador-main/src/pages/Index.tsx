
import React from 'react';
import { QuizGame } from '../components/QuizGame';

const Index = () => {
  return <QuizGame />;
};

export default Index;
